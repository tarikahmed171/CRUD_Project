<h1>Create Record</h1>

<form method=get action=create_result.php>
	f0: <input type=text name=f0> <br>
	<p>
	f1: <input type=text name=f1> <br>
	<p>
	<input type=submit value=Insert>
</form>